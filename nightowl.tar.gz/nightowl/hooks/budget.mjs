#!/usr/bin/env node
/**
 * PostToolUse hook — the model-facing half of the budget tracker.
 *
 * Fires after every successful tool call in EVERY Claude Code session on this
 * machine, so the overwhelming majority of invocations must do nothing and
 * exit fast. The guard chain, cheapest check first:
 *
 *   1. no active-run state file            → silent (normal interactive work)
 *   2. state file is for a different session → silent (a run in another tab)
 *   3. state is stale (runner died)          → silent, and clean up
 *   4. no phase boundary crossed             → silent
 *   5. otherwise                             → inject one short line
 *
 * Output contract (Claude Code hooks reference):
 *   { "hookSpecificOutput": { "hookEventName": "PostToolUse",
 *                             "additionalContext": "..." } }
 * Claude Code wraps that string in a system reminder and inserts it at the
 * point the hook fired; the model reads it on the next request. It does not
 * appear in the transcript as a chat message.
 *
 * This hook NEVER exits non-zero and never writes to stderr on the happy path.
 * Exit code 2 would block the tool loop, and a budget reminder is not worth
 * blocking anyone's work over.
 */

import { readState, shouldInject, markInjected, clearState } from '../lib/tracker.mjs';

const STALE_MS = 10 * 60 * 1000; // runner should update at least once a second

/**
 * Read the event JSON, but never wait forever. If stdin is somehow not
 * delivered we would otherwise sit inside the agent's tool loop until the
 * hook timeout fires, adding latency to every single tool call.
 */
async function readStdin(timeoutMs = 1500) {
  if (process.stdin.isTTY) return {};
  const chunks = [];
  const collect = (async () => {
    for await (const chunk of process.stdin) chunks.push(chunk);
  })();
  await Promise.race([collect, new Promise((r) => setTimeout(r, timeoutMs))]);
  try {
    return JSON.parse(Buffer.concat(chunks).toString() || '{}');
  } catch {
    return {};
  }
}

async function main() {
  // Read the event FIRST: state is keyed by session, so we cannot look
  // anything up until we know which session we are in.
  const event = await readStdin();
  if (!event.session_id) return;

  const state = await readState(event.session_id);
  if (!state || !state.budget) return;

  // The runner crashed or was killed without cleaning up. Go quiet.
  if (Date.now() - (state.updatedAt || 0) > STALE_MS) {
    await clearState(event.session_id);
    return;
  }

  const message = shouldInject(state);
  if (!message) return;

  process.stdout.write(
    JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'PostToolUse',
        additionalContext: message,
      },
    }),
  );

  await markInjected(state);
}

// Any failure at all: say nothing, exit clean. A broken tracker must never be
// visible to the user or the model.
main()
  .catch(() => {})
  .finally(() => process.exit(0));
