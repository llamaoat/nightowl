#!/usr/bin/env node
/**
 * Stop hook — the one question, at the one moment it is worth asking.
 *
 * WHY Stop AND NOT SessionEnd
 * ---------------------------
 * SessionEnd fires when a session terminates but cannot block termination, so
 * anything it asks arrives after the user has gone. Stop fires when Claude
 * finishes a turn and the conversation stays open, so a question posed here
 * reaches someone who is still sitting there. That is the difference between
 * asking and talking to an empty room.
 *
 * WHY ASK AT ALL, GIVEN repo.mjs
 * ------------------------------
 * Git archaeology resolves most of the abandoned-vs-interrupted ambiguity for
 * free: superseded todos, dead repos, deleted branches, vanished files. What
 * it cannot resolve is the silent case — an old session in a live repo where
 * simply nothing has happened. No commits, no changes, no evidence either way.
 * That residue is the only thing worth spending a human keystroke on.
 *
 * THE GATE (every condition must hold)
 * ------------------------------------
 *   1. at least one candidate is older than staleDays (default 7)
 *   2. the repo evidence for it is genuinely ambiguous ('silent')
 *   3. we have never asked about that session before
 *   4. we have not asked about anything in the last 24 hours
 *   5. the answer would actually change something — it scores well enough to
 *      be a plausible pick if the user vouches for it
 *
 * In practice that is a question every week or two, about a session where the
 * answer is genuinely load-bearing. If it fires more often than that for you,
 * the gate is wrong and that is a bug worth filing.
 *
 * This hook NEVER blocks. It emits additionalContext and exits 0. Exit 2 on a
 * Stop event would keep the conversation open against the user's wishes, which
 * is far too rude a thing to do over housekeeping.
 */

import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const STATE_DIR = process.env.NIGHTOWL_STATE_DIR || join(homedir(), '.nightowl');
const ASK_STATE = join(STATE_DIR, 'ask.json');

const ASK_COOLDOWN_MS = Number(process.env.NIGHTOWL_ASK_COOLDOWN_H ?? 24) * 3_600_000;
const STALE_DAYS = Number(process.env.NIGHTOWL_STALE_DAYS ?? 7);
const MIN_SCORE_TO_ASK = Number(process.env.NIGHTOWL_ASK_MIN_SCORE ?? 12);

async function readStdin(timeoutMs = 1500) {
  if (process.stdin.isTTY) return {};
  const chunks = [];
  const collect = (async () => {
    for await (const c of process.stdin) chunks.push(c);
  })();
  await Promise.race([collect, new Promise((r) => setTimeout(r, timeoutMs))]);
  try {
    return JSON.parse(Buffer.concat(chunks).toString() || '{}');
  } catch {
    return {};
  }
}

async function main() {
  if (process.env.NIGHTOWL_ASK === 'off') return;

  const event = await readStdin();
  // stop_hook_active means we are already inside a continuation we caused.
  // Asking again here is how you build an infinite loop.
  if (event.stop_hook_active) return;

  // Cooldown first — cheapest possible exit on the common path.
  try {
    const st = JSON.parse(await readFile(ASK_STATE, 'utf8'));
    if (Date.now() - (st.lastAsk || 0) < ASK_COOLDOWN_MS) return;
  } catch { /* never asked */ }

  const { loadSessions } = await import(join(HERE, '..', 'lib', 'sessions.mjs'));
  const { getQuota, spendableBudget } = await import(join(HERE, '..', 'lib', 'quota.mjs'));
  const { rankSessions } = await import(join(HERE, '..', 'lib', 'score.mjs'));

  let config = {};
  try {
    config = JSON.parse(await readFile(join(STATE_DIR, 'config.json'), 'utf8'));
  } catch { /* defaults */ }

  const staleDays = config.ask?.staleDays ?? STALE_DAYS;

  const { getAdapter, DEFAULT_ADAPTER } = await import(join(HERE, '..', 'lib', 'adapters', 'index.mjs'));
  const sessions = await loadSessions({
    adapter: getAdapter(config.adapter ?? DEFAULT_ADAPTER),
    projectsDir: config.projectsDir,
    maxAgeDays: config.maxAgeDays ?? 30,
  });
  if (!sessions.length) return;

  const quota = await getQuota(sessions, config);
  const budgetInfo = spendableBudget(quota, config);
  const candidates = await rankSessions(sessions, budgetInfo.budget, { checkGit: true });

  const target = candidates.find(
    (c) =>
      c.ageDays >= staleDays &&
      c.certainty === 'ambiguous' &&
      !c.asked &&
      c.score >= MIN_SCORE_TO_ASK,
  );
  if (!target) return;

  const days = Math.round(target.ageDays);
  const done = target.session.todoTotal
    ? `${target.session.todoDone}/${target.session.todoTotal} done`
    : 'no todo list';

  const ask =
    `[nightowl] Housekeeping, only if the user has a moment. One stalled session is ` +
    `ambiguous: "${target.title}" in ${target.session.cwd} — last touched ${days} days ago, ` +
    `${done}, and the repo shows no commits or changes since, so there is no way to tell ` +
    `whether it was abandoned or just interrupted.\n\n` +
    `Ask the user ONE short question: is that project still live, dead, or should it be ` +
    `snoozed? Ask it plainly and briefly, and only if they are not mid-task. Do not ` +
    `pressure them and do not ask a second question.\n\n` +
    `Record their answer by running exactly one of:\n` +
    `  nightowl verdict ${target.session.id} live\n` +
    `  nightowl verdict ${target.session.id} dead\n` +
    `  nightowl verdict ${target.session.id} snooze\n` +
    `If they ignore it or change the subject, drop it silently and do not raise it again.`;

  process.stdout.write(
    JSON.stringify({
      hookSpecificOutput: { hookEventName: 'Stop', additionalContext: ask },
    }),
  );

  await mkdir(STATE_DIR, { recursive: true });
  await writeFile(
    ASK_STATE,
    JSON.stringify({ lastAsk: Date.now(), sessionId: target.session.id }),
  );
}

main()
  .catch(() => {})
  .finally(() => process.exit(0));
