#!/usr/bin/env node
/**
 * SessionStart hook: one line, only when it matters.
 *
 * The fastest way to make a tool like this hated is to print something on
 * every single session start. So this stays silent unless ALL of these hold:
 *   - urgency is past the threshold (a lot unused, window nearly over)
 *   - there is actually spendable budget after reserves
 *   - there is a candidate scoring above the floor
 *   - we haven't already nudged within the cooldown
 *
 * In practice that means it speaks up a few times a week, not a few times
 * an hour. Exit 0 with empty stdout = no interruption.
 */

import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const STATE_DIR = join(homedir(), '.nightowl');
const NUDGE_STATE = join(STATE_DIR, 'nudge.json');

const URGENCY_THRESHOLD = Number(process.env.NIGHTOWL_URGENCY ?? 0.45);
const MIN_SCORE = Number(process.env.NIGHTOWL_MIN_SCORE ?? 40);
const COOLDOWN_MS = Number(process.env.NIGHTOWL_COOLDOWN_MIN ?? 240) * 60_000;

async function main() {
  if (process.env.NIGHTOWL_NUDGE === 'off') return;

  const { loadSessions } = await import(join(HERE, '..', 'lib', 'sessions.mjs'));
  const { getQuota, spendableBudget, idleUrgency } = await import(join(HERE, '..', 'lib', 'quota.mjs'));
  const { rankSessions } = await import(join(HERE, '..', 'lib', 'score.mjs'));

  let config = {};
  try {
    config = JSON.parse(await readFile(join(STATE_DIR, 'config.json'), 'utf8'));
  } catch { /* defaults are fine */ }

  // Cooldown check first — cheapest possible exit.
  try {
    const state = JSON.parse(await readFile(NUDGE_STATE, 'utf8'));
    if (Date.now() - (state.lastNudge || 0) < COOLDOWN_MS) return;
  } catch { /* no state yet */ }

  const { getAdapter, DEFAULT_ADAPTER } = await import(join(HERE, '..', 'lib', 'adapters', 'index.mjs'));
  const sessions = await loadSessions({
    adapter: getAdapter(config.adapter ?? DEFAULT_ADAPTER),
    projectsDir: config.projectsDir,
    maxAgeDays: config.maxAgeDays ?? 14,
  });
  if (!sessions.length) return;

  const quota = await getQuota(sessions, config);
  const urgency = idleUrgency(quota);
  if (urgency < URGENCY_THRESHOLD) return;

  const budgetInfo = spendableBudget(quota, config);
  if (budgetInfo.blocked || budgetInfo.budget <= 0) return;

  // Skip BOTH git probes and repo archaeology here. A hook must not block
  // session start, and archaeology runs `git log --since` once per session
  // across every project you have ever worked in — easily seconds of latency
  // on a busy machine, paid every time you open Claude Code. The nudge only
  // needs a rough ranking; `nightowl status` does the accurate version.
  const candidates = await rankSessions(sessions, budgetInfo.budget, {
    checkGit: false,
    checkRepo: false,
  });
  if (!candidates.length || candidates[0].score < MIN_SCORE) return;

  const top = candidates[0];
  const mins = Math.round(quota.msUntilReset / 60_000);
  const k = (n) => `${Math.round(n / 1000)}k`;

  const line =
    `[nightowl] ~${k(budgetInfo.budget)} tokens expire in ${mins}m. ` +
    `Closest to done: "${top.title}" in ${top.session.cwd} ` +
    `(${top.session.todoDone}/${top.session.todoTotal} todos, needs ~${k(top.estTokens)}). ` +
    `Run /nightowl to see the full list.`;

  // additionalContext is surfaced to Claude at session start; stdout is the
  // documented channel for SessionStart hooks.
  console.log(line);

  await mkdir(STATE_DIR, { recursive: true });
  await writeFile(
    NUDGE_STATE,
    JSON.stringify({ lastNudge: Date.now(), sessionId: top.session.id }),
  );
}

// Never let a hook failure block a session from starting.
main().catch(() => process.exit(0));
