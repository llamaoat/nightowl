/**
 * Notification tests.
 *
 * The load-bearing invariant: notifications must NEVER affect the run. A flaky
 * network or a missing `notify-send` must not turn a successful unattended run
 * into a failed one, and must never throw into the runner.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, '..');

let passed = 0, failed = 0;
function assert(name, cond, detail = '') {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else { failed++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
}

const { summarise, notify } = await import(join(ROOT, 'lib', 'notify.mjs'));

const candidate = { title: 'Add unit tests for the parser' };

console.log('\n  summarising a finished run\n');

const ok = summarise({ exitCode: 0, spent: 24_000, budgetTokens: 30_000 }, candidate);
assert('a clean finish is reported as ok', ok.urgency === 'ok');
assert('and names the task', ok.body.includes('Add unit tests'));
assert('and states what it spent', /24k of 30k/.test(ok.body), ok.body);

const broke = summarise({ exitCode: 0, spent: 30_100, budgetTokens: 30_000, killedForBudget: true }, candidate);
assert('hitting the ceiling is a distinct, warned outcome', broke.urgency === 'warn');
assert('and says the budget was used up', /budget used up/i.test(broke.title), broke.title);
assert('and points at the handoff note', /handoff/i.test(broke.body));

const failedLaunch = summarise({ error: 'spawn claude ENOENT' }, candidate);
assert('a failed launch is an error, not a success', failedLaunch.urgency === 'error');
assert('and includes the cause', failedLaunch.body.includes('ENOENT'));

const early = summarise({ exitCode: 1, spent: 5_000, budgetTokens: 30_000 }, candidate);
assert('a non-zero exit is warned, not silently ok', early.urgency === 'warn');

assert('a missing candidate does not crash the summary',
  typeof summarise({ exitCode: 0, spent: 1, budgetTokens: 2 }, null).body === 'string');

// A todo containing a double quote must not break the osascript command.
const quoted = summarise({ exitCode: 0, spent: 1000, budgetTokens: 2000 }, { title: 'fix the "weird" bug' });
assert('a quote in the task title is carried through safely', quoted.body.includes('weird'));

console.log('\n  delivery never breaks a run\n');

const disabled = await notify(ok, { notify: { enabled: false } });
assert('disabled means nothing is attempted', disabled.skipped === 'disabled' && disabled.sent.length === 0);

// Desktop notifier is absent in CI; this must resolve, not throw.
const noNotifier = await notify(ok, { notify: { desktop: true } });
assert('a missing desktop notifier resolves instead of throwing', Array.isArray(noNotifier.sent));
assert('and the failure is reported, not swallowed silently', (noNotifier.failed || []).length >= 0);

const badUrl = await notify(ok, { notify: { desktop: false, ntfy: 'http://127.0.0.1:1/nope' } });
assert('an unreachable ntfy URL does not throw', Array.isArray(badUrl.sent));
assert('and is recorded as failed', (badUrl.failed || []).length === 1, JSON.stringify(badUrl));

const bothBad = await notify(ok, {
  notify: { desktop: true, ntfy: 'http://127.0.0.1:1/nope', webhook: 'http://127.0.0.1:1/nope' },
});
assert('every channel failing still resolves cleanly', bothBad.sent.length === 0 && bothBad.failed.length === 3, JSON.stringify(bothBad));

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed) process.exitCode = 1;
