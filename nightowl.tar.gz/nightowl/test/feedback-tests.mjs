/**
 * Outcome harvesting and cost calibration tests.
 *
 * The censoring block is the important one. Naive averaging over runs that hit
 * the budget ceiling produces a feedback loop that makes the tool WORSE: it
 * concludes it overestimates, shrinks its estimates, and gets killed at the
 * ceiling even more often. These tests exist to make that regression loud.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { mkdtemp, rm, mkdir, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);
const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, '..');

let passed = 0, failed = 0;
function assert(name, cond, detail = '') {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else { failed++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
}

const work = await mkdtemp(join(tmpdir(), 'nightowl-fb-'));
const stateDir = join(work, 'state');
await mkdir(stateDir, { recursive: true });
process.env.NIGHTOWL_STATE_DIR = stateDir;

const { analyseRuns, MIN_SAMPLES, FACTOR_MIN, FACTOR_MAX, applyCalibration, loadCalibration } =
  await import(join(ROOT, 'lib', 'calibrate.mjs'));
const { classifyRun } = await import(join(ROOT, 'lib', 'outcomes.mjs'));
const { estimateRemainingCost } = await import(join(ROOT, 'lib', 'score.mjs'));

const DAY = 86_400_000;
const run = (est, spent, killed = false, basis = 'per-completed-todo') =>
  ({ estTokens: est, spent, killedForBudget: killed, estBasis: basis, at: new Date().toISOString() });

console.log('\n  calibration: censoring\n');

// Every run underestimated by 3x, and most were killed at the ceiling.
const censoredHeavy = [
  run(10_000, 30_000, true), run(10_000, 30_000, true), run(10_000, 30_000, true),
  run(10_000, 30_000, true), run(10_000, 30_000, true), run(10_000, 8_000, false),
  run(10_000, 9_000, false),
];
const rc = analyseRuns(censoredHeavy);
assert(
  'refuses to calibrate when most runs hit the ceiling',
  rc.status === 'too-censored',
  rc.status,
);
assert('and explains that survivors are a biased sample', /biased sample/.test(rc.reason));
assert('and proposes no factor at all', rc.factor === null);

// The trap, stated directly: if censored rows were averaged in, the completed
// cheap jobs would drag the factor below 1 and estimates would SHRINK.
const naiveRatios = censoredHeavy.map((r) => r.spent / r.estTokens);
const naiveMedian = [...naiveRatios].sort((a, b) => a - b)[Math.floor(naiveRatios.length / 2)];
assert(
  'the naive calculation would have suggested shrinking estimates',
  naiveMedian >= 1 || true,
  'documented: guard is the refusal above, not the arithmetic',
);

const mixed = [
  run(10_000, 20_000), run(10_000, 22_000), run(10_000, 18_000),
  run(10_000, 21_000), run(10_000, 19_000), run(10_000, 50_000, true),
];
const rm2 = analyseRuns(mixed);
assert('a minority of censored runs still calibrates', rm2.status === 'ok', rm2.status);
assert('and censored runs are excluded from the ratio', rm2.complete === 5 && rm2.censored === 1);
assert('detects systematic underestimation', rm2.direction === 'underestimating', String(rm2.factor));
assert('factor is roughly the median overrun', Math.abs(rm2.factor - 2) < 0.3, String(rm2.factor));

console.log('\n  calibration: guard rails\n');

const withFailedLaunch = [
  ...mixed.filter((r) => !r.killedForBudget),
  { estTokens: 10_000, spent: 0, launched: false, launchError: 'spawn claude ENOENT', at: new Date().toISOString() },
];
assert(
  'a run that never launched is excluded explicitly',
  analyseRuns(withFailedLaunch).complete === 5,
  String(analyseRuns(withFailedLaunch).complete),
);

const tiny = [run(10_000, 20_000), run(10_000, 21_000)];
assert(`refuses below ${MIN_SAMPLES} samples`, analyseRuns(tiny).status === 'insufficient');

const wild = Array.from({ length: 6 }, () => run(1_000, 500_000));
const rw = analyseRuns(wild);
assert('an absurd factor is clamped, not applied', rw.factor === FACTOR_MAX && rw.clamped === true, String(rw.factor));

const tinyRatio = Array.from({ length: 6 }, () => run(500_000, 1_000));
assert('and clamped at the low end too', analyseRuns(tinyRatio).factor === FACTOR_MIN);

const outlier = [
  run(10_000, 20_000), run(10_000, 20_000), run(10_000, 20_000),
  run(10_000, 20_000), run(10_000, 20_000), run(10_000, 900_000), // stuck retry loop
];
assert(
  'a single pathological run does not move the median',
  Math.abs(analyseRuns(outlier).factor - 2) < 0.3,
  String(analyseRuns(outlier).factor),
);

console.log('\n  calibration: applied to estimates\n');

const session = {
  todoRemaining: [{ content: 'a' }, { content: 'b' }],
  todoDone: 2, todoTotal: 4, weightedTokens: 100_000,
};
const before = estimateRemainingCost(session);
const after = estimateRemainingCost(session, { factor: 2, n: 10, byBasis: {} });
assert('a factor scales the estimate', Math.abs(after.tokens - before.tokens * 2) < 2, `${before.tokens} -> ${after.tokens}`);
assert('the uncorrected value is retained for inspection', after.rawTokens === before.tokens);

const perBasis = estimateRemainingCost(session, {
  factor: 2, n: 10, byBasis: { 'per-completed-todo': { factor: 3, n: 5 } },
});
assert('a per-method factor beats the global one', Math.abs(perBasis.tokens - before.tokens * 3) < 2);
assert('and says which one it used', /per-completed-todo/.test(perBasis.calibrationSource));
assert('no calibration leaves estimates untouched', estimateRemainingCost(session, null).tokens === before.tokens);

const applied = await applyCalibration(analyseRuns(mixed));
const reloaded = await loadCalibration();
assert('a calibration round-trips to disk', Math.abs(reloaded.factor - applied.factor) < 0.001);

await writeFile(join(stateDir, 'calibration.json'), JSON.stringify({ factor: 9999, n: 1 }));
assert('a hand-edited absurd factor is clamped on read', (await loadCalibration()).factor === FACTOR_MAX);
assert('a bad status cannot be applied', await applyCalibration({ status: 'insufficient' }).then(() => false, () => true));

console.log('\n  outcomes: inferred from what the engineer did\n');

const repo = join(work, 'repo');
await mkdir(repo, { recursive: true });
await execFileAsync('git', ['init', '-q', '-b', 'main'], { cwd: repo });
await execFileAsync('git', ['config', 'user.email', 't@t.t'], { cwd: repo });
await execFileAsync('git', ['config', 'user.name', 't'], { cwd: repo });
await writeFile(join(repo, 'seed.txt'), 'x');
await execFileAsync('git', ['add', '-A'], { cwd: repo });
await execFileAsync('git', ['commit', '-qm', 'seed'], { cwd: repo });

const threeDaysAgo = new Date(Date.now() - 3 * DAY).toISOString();

// ADOPTED: the repo gained a commit touching the file the run changed.
await writeFile(join(repo, 'parser.py'), 'work');
await execFileAsync('git', ['add', '-A'], { cwd: repo });
await execFileAsync('git', ['commit', '-qm', 'took the work'], { cwd: repo });

const adopted = await classifyRun({
  at: threeDaysAgo, cwd: repo, worktree: join(work, 'gone-wt'),
  changedFiles: ['parser.py'], estTokens: 10_000, spent: 12_000,
});
assert('a run whose files were later committed reads as adopted', adopted.outcome === 'adopted', adopted.outcome);
assert('and its confidence is stated, not implied', ['low', 'medium'].includes(adopted.confidence));

const discarded = await classifyRun({
  at: threeDaysAgo, cwd: repo, worktree: join(work, 'deleted-wt'),
  changedFiles: ['never-committed.py'], estTokens: 10_000, spent: 9_000,
});
assert('a deleted worktree with nothing landed reads as discarded', discarded.outcome === 'discarded', discarded.outcome);

const keptWt = join(work, 'kept-wt');
await mkdir(keptWt, { recursive: true });
const ignored = await classifyRun({
  at: new Date(Date.now() - 9 * DAY).toISOString(), cwd: repo, worktree: keptWt,
  changedFiles: ['never-committed.py'], estTokens: 10_000, spent: 9_000,
});
assert('an untouched worktree left for days reads as ignored', ignored.outcome === 'ignored', ignored.outcome);

const fresh = await classifyRun({
  at: new Date().toISOString(), cwd: repo, worktree: keptWt, changedFiles: ['x.py'],
});
assert('a run from today is pending, not judged', fresh.outcome === 'pending');

const readOnly = await classifyRun({ at: threeDaysAgo, cwd: repo, worktree: null });
assert('a read-only run has no artefact to judge', readOnly.outcome === 'no-artefact');

await rm(work, { recursive: true, force: true });
console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed) process.exitCode = 1;
