/**
 * Budget tracker tests.
 *
 * The critical invariants are about SILENCE. A tracker that speaks too often
 * eats the budget it exists to protect, and a tracker that speaks in someone
 * else's interactive session is a bug users would rightly hate.
 */
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';

const execFileAsync = promisify(execFile);
const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, '..');

let passed = 0;
let failed = 0;
function assert(name, cond, detail = '') {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`);
  }
}

const stateDir = await mkdtemp(join(tmpdir(), 'nightowl-tracker-'));
process.env.NIGHTOWL_STATE_DIR = stateDir;

const {
  phaseFor,
  buildInjection,
  shouldInject,
  markInjected,
  initState,
  updateSpend,
  clearState,
  systemPromptAppendix,
  ACTIVE_DIR,
  PHASES,
} = await import(join(ROOT, 'lib', 'tracker.mjs'));

console.log('\n  phase transitions\n');

assert('0% spent is explore', phaseFor(0, 100_000).name === 'explore');
assert('49% spent is still explore', phaseFor(49_000, 100_000).name === 'explore');
assert('50% spent is consolidate', phaseFor(50_000, 100_000).name === 'consolidate');
assert('80% spent is wrap-up', phaseFor(80_000, 100_000).name === 'wrap-up');
assert('95% spent is land', phaseFor(95_000, 100_000).name === 'land');
assert('a zero budget never crashes', phaseFor(500, 0).name === 'explore');

console.log('\n  injection policy (silence is the default)\n');

let state = await initState({ runId: 'r1', sessionId: 's1', budget: 100_000 });

assert('silent at the start of a run', shouldInject(state) === null);

await updateSpend(state, 30_000);
assert('silent inside the opening phase', shouldInject(state) === null, 'explore is covered by the system prompt');

await updateSpend(state, 55_000);
const first = shouldInject(state);
assert('speaks on crossing into consolidate', typeof first === 'string');
assert('the message names the phase guidance', first.includes('Finish the item you have open'));
assert('the message states remaining and percent', /45k of 100k/.test(first) && /55%/.test(first));

await markInjected(state);
assert('silent immediately after injecting', shouldInject(state) === null);

await updateSpend(state, 60_000);
assert('silent on further spend inside the same phase', shouldInject(state) === null);

await updateSpend(state, 80_000);
assert(
  'rate limit suppresses a fast second injection',
  shouldInject(state) === null,
  'crossed into wrap-up but within the 45s floor',
);
assert(
  'the same crossing fires once the interval has passed',
  typeof shouldInject(state, Date.now() + 60_000) === 'string',
);

console.log('\n  overhead\n');

state.lastInjectedPhase = null;
const sizes = [];
for (const frac of [0.55, 0.8, 0.95]) {
  state.spent = 100_000 * frac;
  state.lastInjectedPhase = null;
  sizes.push(buildInjection(state).length);
}
const totalChars = sizes.reduce((a, b) => a + b, 0);
const approxTokens = Math.ceil(totalChars / 4);
assert(
  `whole-run injection overhead stays trivial (~${approxTokens} tokens across 3 injections)`,
  approxTokens < 250,
  `${approxTokens} tokens`,
);
assert('each injection is a single line', sizes.every((_, i) => !buildInjection(state).includes('\n')));

console.log('\n  system prompt appendix\n');

const plain = systemPromptAppendix();
assert('explains the reminder marker', plain.includes('[budget]'));
assert('tells the model not to reply to reminders', /planning input/.test(plain));
assert('--terse adds output style rules only when asked', !plain.includes('OUTPUT STYLE'));
assert('--terse rules appear when requested', systemPromptAppendix({ terse: true }).includes('OUTPUT STYLE'));

console.log('\n  hook handshake\n');

// execFile has no `input` option — the hook reads a JSON event on stdin, so we
// have to spawn and write to it ourselves.
async function runHook(stdinObj) {
  const { spawn } = await import('node:child_process');
  return new Promise((resolve) => {
    const child = spawn('node', [join(ROOT, 'hooks', 'budget.mjs')], {
      env: { ...process.env, NIGHTOWL_STATE_DIR: stateDir },
      stdio: ['pipe', 'pipe', 'ignore'],
    });
    let out = '';
    child.stdout.on('data', (d) => (out += d.toString()));
    child.on('close', () => resolve(out));
    child.stdin.write(JSON.stringify(stdinObj));
    child.stdin.end();
  });
}

await clearState('s1');
assert(
  'hook is silent with no active run (the normal case)',
  (await runHook({ session_id: 'whatever', hook_event_name: 'PostToolUse' })) === '',
);

state = await initState({ runId: 'r2', sessionId: 'target-session', budget: 100_000 });
await updateSpend(state, 60_000);

assert(
  'hook is silent for a different session',
  (await runHook({ session_id: 'some-other-session' })) === '',
);

// Regression: two concurrent runs must not clobber each other's budget.
const runA = await initState({ runId: 'A', sessionId: 'concurrent-A', budget: 100_000 });
const runB = await initState({ runId: 'B', sessionId: 'concurrent-B', budget: 40_000 });
await updateSpend(runA, 60_000);
await updateSpend(runB, 5_000);
const { readState: rs } = await import(join(ROOT, 'lib', 'tracker.mjs'));
const backA = await rs('concurrent-A');
const backB = await rs('concurrent-B');
assert(
  'concurrent runs keep separate state',
  backA.budget === 100_000 && backB.budget === 40_000,
  `A=${backA?.budget} B=${backB?.budget}`,
);
// A phase-changing update flushes to disk immediately; sub-second updates
// inside the same phase are throttled, because a run emits hundreds of usage
// blocks and this is on the hot path. Injection keys off phase, so the
// throttle can never delay a reminder.
assert('a phase-crossing update flushes immediately', backA.spent === 60_000);
assert('the quiet run stays in its own phase', backB.phase === 'explore' && backA.phase === 'consolidate');
await new Promise((r) => setTimeout(r, 1100));
await updateSpend(runB, 6_000);
assert('a throttled update flushes once stale', (await rs('concurrent-B')).spent === 6_000);
await clearState('concurrent-A');
await clearState('concurrent-B');

const out = await runHook({ session_id: 'target-session', hook_event_name: 'PostToolUse' });
let parsed = null;
try {
  parsed = JSON.parse(out);
} catch { /* leave null */ }

assert('hook emits valid JSON for the target session', parsed !== null, JSON.stringify(out));
assert(
  'hook uses the documented output contract',
  parsed?.hookSpecificOutput?.hookEventName === 'PostToolUse' &&
    typeof parsed?.hookSpecificOutput?.additionalContext === 'string',
);
assert(
  'injected text is the budget line',
  parsed?.hookSpecificOutput?.additionalContext?.startsWith('[budget]'),
);

assert(
  'hook does not repeat itself on the next tool call',
  (await runHook({ session_id: 'target-session' })) === '',
);

// Simulate the runner dying without cleanup.
state.updatedAt = Date.now() - 60 * 60 * 1000;
state.lastInjectedPhase = null;
const { writeFile } = await import('node:fs/promises');
const { statePathFor } = await import(join(ROOT, 'lib', 'tracker.mjs'));
await writeFile(statePathFor('target-session'), JSON.stringify(state));
assert(
  'hook goes quiet when the runner has died',
  (await runHook({ session_id: 'target-session' })) === '',
);

console.log('\n  hook cost when idle\n');
const { existsSync } = await import('node:fs');
assert(
  'the active dir is retired once no runs remain',
  !existsSync(ACTIVE_DIR),
  'the shell guard in hooks.json keys off this, so a stale dir means a 54ms tax per tool call',
);

await rm(stateDir, { recursive: true, force: true });

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed) process.exitCode = 1;
