/**
 * Eval harness tests.
 *
 * The first block is the most important in the whole project: it proves the
 * replay cannot see the future. If leakage tests pass trivially, every number
 * the harness reports is worthless — and worse, flatteringly worthless.
 */
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { mkdtemp, rm, mkdir, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';

const execFileAsync = promisify(execFile);
const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, '..');

let passed = 0, failed = 0;
function assert(name, cond, detail = '') {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else { failed++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
}

const work = await mkdtemp(join(tmpdir(), 'nightowl-eval-'));
process.env.NIGHTOWL_STATE_DIR = join(work, 'state');

const { repoEvidence, evidenceVerdict } = await import(join(ROOT, 'lib', 'repo.mjs'));
const { stallPoints, buildLabelledMoments, wilson, BASELINES } = await import(join(ROOT, 'lib', 'eval.mjs'));
const { parseSession } = await import(join(ROOT, 'lib', 'sessions.mjs'));

const HOUR = 3_600_000, DAY = 86_400_000;

console.log('\n  LEAKAGE: the replay must not see the future\n');

// A repo where the todo is superseded by a commit made AFTER the eval point.
const repoDir = join(work, 'repo');
await mkdir(repoDir, { recursive: true });
await execFileAsync('git', ['init', '-q', '-b', 'main'], { cwd: repoDir });
await execFileAsync('git', ['config', 'user.email', 't@t.t'], { cwd: repoDir });
await execFileAsync('git', ['config', 'user.name', 't'], { cwd: repoDir });

const stalledAt = Date.now() - 20 * DAY;
const evalPoint = stalledAt + HOUR;

async function commitAt(subject, when) {
  await writeFile(join(repoDir, `${Math.random().toString(36).slice(2)}.txt`), 'x');
  await execFileAsync('git', ['add', '-A'], { cwd: repoDir });
  const iso = new Date(when).toISOString();
  await execFileAsync('git', ['commit', '-qm', subject], {
    cwd: repoDir,
    env: { ...process.env, GIT_AUTHOR_DATE: iso, GIT_COMMITTER_DATE: iso },
  });
}
await commitAt('scaffold the parser', stalledAt - DAY);
await commitAt('add unit tests for the parser', stalledAt + 5 * DAY); // THE FUTURE

const sess = {
  cwd: repoDir,
  lastTimestamp: stalledAt,
  gitBranch: 'main',
  filesTouched: [],
  todoRemaining: [{ content: 'Add unit tests for the parser', status: 'pending' }],
  todoDone: 1, todoTotal: 2,
};

const withHindsight = evidenceVerdict(await repoEvidence(sess), sess);
assert(
  'without a cutoff, the future commit IS visible (control)',
  withHindsight.verdict === 'superseded',
  withHindsight.verdict,
);

const timeTravelled = evidenceVerdict(await repoEvidence(sess, { until: evalPoint, now: evalPoint }), sess);
assert(
  'with until=T, the future commit is INVISIBLE',
  timeTravelled.verdict !== 'superseded',
  `leaked: ${timeTravelled.verdict}`,
);

const evTT = await repoEvidence(sess, { until: evalPoint, now: evalPoint });
assert('present-tense signals are disabled, not faked', evTT.dirty === 0 && evTT.branchExists === null && evTT.timeTravelling === true);
assert('and the cutoff is recorded so results can be interpreted', evTT.timeTravelling === true);

// Transcript truncation
const tDir = join(work, 'projects', '-tmp-proj');
await mkdir(tDir, { recursive: true });
const mk = (role, t, text) => JSON.stringify({
  type: role, sessionId: 'sess-trunc', cwd: repoDir, timestamp: new Date(t).toISOString(),
  message: { role, content: text, ...(role === 'assistant' ? { usage: { input_tokens: 100, output_tokens: 50 } } : {}) },
});
const jsonl = [
  mk('user', stalledAt - 2 * HOUR, 'start'),
  mk('assistant', stalledAt - HOUR, 'working'),
  mk('user', stalledAt + 10 * DAY, 'came back'),
  mk('assistant', stalledAt + 10 * DAY + 1000, 'resumed work'),
].join('\n');
await writeFile(join(tDir, 'sess-trunc.jsonl'), jsonl);

const truncated = await parseSession(join(tDir, 'sess-trunc.jsonl'), '-tmp-proj', { until: evalPoint });
const complete = await parseSession(join(tDir, 'sess-trunc.jsonl'), '-tmp-proj');
assert('full parse sees all four turns', complete.turns === 4);
assert('truncated parse sees only what preceded T', truncated.turns === 2, `saw ${truncated.turns}`);
assert('truncated lastTimestamp precedes the cutoff', truncated.lastTimestamp < evalPoint);

console.log('\n  labels from history\n');

const s1 = { id: 's1', turnTimes: [0, HOUR, 20 * HOUR, 21 * HOUR] };
const sp = stallPoints(s1, 6 * HOUR);
assert('a long gap is a stall point', sp.length === 2, JSON.stringify(sp));
assert('a gap followed by more turns records the resume time', sp[0].resumedAt === 20 * HOUR);
assert('the final turn is a stall with no resume', sp[1].resumedAt === null);
assert('short gaps are not stalls', stallPoints({ turnTimes: [0, HOUR, 2 * HOUR] }, 6 * HOUR).length === 1);

// A pool needs at least two stalled sessions to test a ranking, so the
// fixture provides competitors that are stalled at the same moment.
const now = Date.now();
const labelled = buildLabelledMoments(
  [
    { id: 'resumed', turnTimes: [now - 60 * DAY, now - 59 * DAY, now - 50 * DAY] },
    { id: 'abandoned', turnTimes: [now - 60 * DAY, now - 59.9 * DAY] },
    { id: 'filler', turnTimes: [now - 61 * DAY, now - 60.9 * DAY] },
    { id: 'too-recent', turnTimes: [now - 2 * DAY, now - 1.9 * DAY] },
  ],
  { stallGapHours: 6, horizonDays: 14, now },
);
const flat = [...labelled.moments.values()].flat();
assert('a session resumed within the horizon is a positive', flat.some((m) => m.sessionId === 'resumed' && m.label === 1));
assert('a session never resumed is a negative', flat.some((m) => m.sessionId === 'abandoned' && m.label === 0));
assert(
  'a stall too recent to know about is CENSORED, not scored as a negative',
  !flat.some((m) => m.sessionId === 'too-recent') && labelled.censored > 0,
  'counting these as negatives would systematically punish recency',
);

console.log('\n  statistics\n');

const [lo, hi] = wilson(5, 10);
assert('a Wilson interval on 10 samples is honestly wide', hi - lo > 0.4, `${lo.toFixed(2)}–${hi.toFixed(2)}`);
assert('a Wilson interval on 1000 samples is tight', wilson(500, 1000)[1] - wilson(500, 1000)[0] < 0.08);
assert('zero successes does not produce a negative bound', wilson(0, 20)[0] >= 0);

console.log('\n  baselines\n');

const fake = [
  { session: { id: 'a', lastTimestamp: 100, todoRemaining: [1, 2, 3] }, score: 10 },
  { session: { id: 'b', lastTimestamp: 300, todoRemaining: [1] }, score: 50 },
];
assert('recency baseline sorts by last activity', BASELINES.recency(fake)[0].session.id === 'b');
assert('mostTodos baseline sorts by remaining work', BASELINES.mostTodos(fake)[0].session.id === 'a');
assert('the model baseline preserves score order', BASELINES.model(fake)[0].session.id === 'a');
assert('baselines do not mutate the input', fake[0].session.id === 'a');

await rm(work, { recursive: true, force: true });
console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed) process.exitCode = 1;
