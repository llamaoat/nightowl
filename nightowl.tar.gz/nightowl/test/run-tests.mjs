/**
 * Behavioural tests for the ranking model. These assert the *invariants* that
 * make the tool trustworthy, not exact scores — scores are allowed to drift as
 * the model is tuned, but the orderings below must hold or the tool is unsafe.
 */
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const execFileAsync = promisify(execFile);
const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, '..');
const FIXTURES = '/tmp/nightowl-test-fixtures/projects';

let passed = 0;
let failed = 0;

function assert(name, cond, detail = '') {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`);
  }
}

async function run() {
  await execFileAsync('node', [join(HERE, 'make-fixtures.mjs'), FIXTURES]);

  const configPath = '/tmp/nightowl-test-config.json';
  const { writeFile } = await import('node:fs/promises');
  await writeFile(
    configPath,
    JSON.stringify({ projectsDir: FIXTURES, quota: { blockLimit: 200000 } }),
  );

  const { stdout } = await execFileAsync(
    'node',
    [join(ROOT, 'bin', 'nightowl.mjs'), 'status', '--json', '--no-git'],
    { env: { ...process.env, NIGHTOWL_CONFIG: configPath, NO_COLOR: '1' } },
  );
  const data = JSON.parse(stdout);
  const byPath = Object.fromEntries(data.candidates.map((c) => [c.cwd.split('/').pop(), c]));

  console.log('\n  ranking invariants\n');

  assert(
    'a completed session is excluded entirely',
    !byPath['blog'],
    'the blog fixture finished cleanly and should never be offered',
  );

  assert(
    'the rate-limited near-done session ranks first',
    data.candidates[0]?.cwd.endsWith('invoice-parser'),
    `got ${data.candidates[0]?.cwd}`,
  );

  assert(
    'a rate-limit stop is detected as such',
    byPath['invoice-parser']?.interruptReason === 'rate-limit',
    `got ${byPath['invoice-parser']?.interruptReason}`,
  );

  assert(
    'a session parked on a question is heavily penalised on autonomy',
    byPath['auth-service']?.breakdown.autonomy < 0.2,
    `autonomy was ${byPath['auth-service']?.breakdown.autonomy}`,
  );

  assert(
    'work far larger than the budget is penalised on fit',
    byPath['monolith']?.breakdown.fit < 0.2,
    `fit was ${byPath['monolith']?.breakdown.fit}`,
  );

  assert(
    'a stale session ranks below a fresh one with similar shape',
    byPath['cli-tool']?.score < byPath['invoice-parser']?.score,
  );

  assert(
    'every candidate carries a human-readable reason',
    data.candidates.every((c) => c.reasons.length > 0),
  );

  console.log('\n  coexisting with Claude Code auto-continue\n');

  const { rankSessions: rk } = await import(join(ROOT, 'lib', 'score.mjs'));
  const interrupted = (ageDays, reason) => ({
    id: `ac-${ageDays}-${reason}`, cwd: null, turns: 10, assistantTurns: 6,
    mutatingCalls: 2, filesTouched: ['a.py'], todoDone: 3, todoTotal: 5,
    todoRemaining: [{ content: 'write tests', status: 'pending' }],
    weightedTokens: 50_000, lastTimestamp: Date.now() - ageDays * 86_400_000,
    interrupted: true, interruptReason: reason, looksComplete: false,
    lastAssistantText: 'progress', perTurnTokens: [], turnTimes: [],
  });
  const scoreOf = async (sess) =>
    (await rk([sess], 100_000, { checkGit: false, checkRepo: false }))[0];

  const freshLimit = await scoreOf(interrupted(0.2, 'rate-limit'));
  const oldLimit = await scoreOf(interrupted(10, 'rate-limit'));
  const freshEsc = await scoreOf(interrupted(0.2, 'user-interrupt'));
  const freshPlain = await scoreOf({ ...interrupted(0.2, null), interrupted: false });

  assert(
    'a fresh limit-stop gets no boost — auto-continue owns it',
    freshLimit.score <= freshPlain.score,
    `limit ${freshLimit.score} vs plain ${freshPlain.score}`,
  );
  assert(
    'and says so, rather than silently down-ranking',
    freshLimit.reasons.some((r) => /auto-continue/.test(r)),
  );
  assert(
    'an OLD limit-stop keeps the boost — auto-continue had its chance',
    oldLimit.reasons.some((r) => /never picked back up/.test(r)),
  );
  assert(
    'a non-limit interrupt keeps its boost outright',
    freshEsc.score > freshPlain.score,
    'auto-continue never covered Esc or a closed laptop',
  );

  console.log('\n  time windows\n');

  const { parseDuration, formatDuration, UNLIMITED } = await import(join(ROOT, 'lib', 'duration.mjs'));

  assert('5d parses to 5 days', parseDuration('5d') === 5);
  assert('1w parses to 7 days', parseDuration('1w') === 7);
  assert('2w parses to 14 days', parseDuration('2w') === 14);
  assert('plural spellings work', parseDuration('2 weeks') === 14);
  assert('hours work', parseDuration('36h') === 1.5);
  assert('a bare number means days', parseDuration('10') === 10);
  assert('"all" means no limit', parseDuration('all') === UNLIMITED);
  assert('0 also means no limit', parseDuration('0') === UNLIMITED);
  assert('a typo throws rather than silently defaulting', (() => {
    try { parseDuration('2weekz'); return false; } catch { return true; }
  })(), 'quietly scanning 30 days when you asked for 5 is indistinguishable from a bug');
  assert('a negative duration is rejected', (() => {
    try { parseDuration('-3d'); return false; } catch { return true; }
  })());
  assert('formatting round-trips weeks', formatDuration(14) === '2 weeks');
  assert('formatting handles all-time', formatDuration(UNLIMITED) === 'all time');

  const windowed = async (w) => {
    const { stdout } = await execFileAsync(
      'node', [join(ROOT, 'bin', 'nightowl.mjs'), 'status', '--json', '--no-git', '--no-repo', '--window', w],
      { env: { ...process.env, NIGHTOWL_CONFIG: configPath, NO_COLOR: '1' } },
    );
    return JSON.parse(stdout).candidates.length;
  };
  const wide = await windowed('all');
  const narrow = await windowed('5d');
  assert('a narrower window returns no more than a wider one', narrow <= wide, `5d=${narrow} all=${wide}`);

  const badWindow = await execFileAsync(
    'node', [join(ROOT, 'bin', 'nightowl.mjs'), 'status', '--window', 'nonsense'],
    { env: { ...process.env, NIGHTOWL_CONFIG: configPath, NO_COLOR: '1' } },
  ).then(() => null, (e) => e);
  assert('a bad window fails cleanly, with no stack trace', badWindow !== null && !/at parseDuration/.test(badWindow.stderr || ''), (badWindow?.stderr || '').slice(0, 80));
  assert('and suggests valid values', /Valid windows/.test(badWindow?.stderr || ''));

  console.log('\n  robustness against messy real histories\n');

  const { rankSessions: rank } = await import(join(ROOT, 'lib', 'score.mjs'));
  const mkSession = (over = {}) => ({
    id: 'x' + Math.random().toString(36).slice(2),
    cwd: null, turns: 10, assistantTurns: 6, mutatingCalls: 3, filesTouched: ['a.py'],
    todoDone: 3, todoTotal: 5, todoRemaining: [{ content: 'write tests', status: 'pending' }],
    weightedTokens: 50_000, lastTimestamp: Date.now() - 86_400_000,
    interrupted: false, looksComplete: false, lastAssistantText: 'made progress',
    perTurnTokens: [], turnTimes: [], ...over,
  });

  // Clock skew, restored backups and timezone bugs all produce future stamps.
  const future = await rank([mkSession({ lastTimestamp: Date.now() + 5 * 86_400_000 })], 100_000, { checkGit: false, checkRepo: false });
  const fresh = await rank([mkSession({ lastTimestamp: Date.now() })], 100_000, { checkGit: false, checkRepo: false });
  assert(
    'a future-dated session ranks no higher than a brand-new one',
    future[0].score <= fresh[0].score,
    `future ${future[0].score} vs fresh ${fresh[0].score} — unclamped, 0.5^negative exceeds 1`,
  );
  assert('and its reported age is never negative', future[0].ageDays >= 0);

  // Out of quota is a fact about the wallet, not about any candidate.
  const broke = await rank(
    [mkSession({ todoDone: 4, todoTotal: 5 }), mkSession({ todoDone: 0, todoTotal: 9, turns: 30 })],
    0,
    { checkGit: false, checkRepo: false },
  );
  assert('with no budget, candidates are still ranked on merit', broke[0].score > 0, `top scored ${broke[0].score}`);
  assert('the nearly-done one still comes first', broke[0].session.todoDone === 4);
  assert('and each is flagged as budget-limited', broke.every((c) => c.budgetExhausted === true));

  assert(
    'a session with no cwd does not crash the ranker',
    (await rank([mkSession({ cwd: null })], 100_000, { checkGit: true, checkRepo: true })).length === 1,
  );

  console.log('\n  chat vs work classification\n');

  const { classifySession, isEligible } = await import(join(ROOT, 'lib', 'classify.mjs'));

  assert(
    'a Q&A session with nothing touched is a chat',
    classifySession({ turns: 4, mutatingCalls: 0, filesTouched: [], todoTotal: 0, readingCalls: 0, searchCalls: 0 }).kind === 'chat',
  );
  assert(
    'editing a file makes it work, regardless of anything else',
    classifySession({ turns: 2, mutatingCalls: 1, filesTouched: ['a.py'], todoTotal: 0 }).kind === 'work',
  );
  assert(
    'a real plan counts as work even with no edits',
    classifySession({ turns: 8, mutatingCalls: 0, filesTouched: [], todoTotal: 5 }).kind === 'work',
    'this is what rescues "we designed it but never started building"',
  );
  assert(
    'heavy reading with nothing written is research, not work',
    classifySession({ turns: 8, mutatingCalls: 0, filesTouched: [], todoTotal: 0, readingCalls: 4, searchCalls: 2 }).kind === 'research',
  );
  assert(
    'a session that edited only via bash is still work',
    classifySession({ turns: 6, mutatingCalls: 2, filesTouched: [], todoTotal: 0, bashCalls: 4 }).kind === 'work',
    'otherwise shell-driven work is misfiled as chat',
  );
  assert('work is eligible', isEligible('work'));
  assert('chat is never eligible, even with the research flag', !isEligible('chat', { includeResearch: true }));
  assert('research is excluded by default', !isEligible('research'));
  assert('research is opt-in', isEligible('research', { includeResearch: true }));
  assert('every classification carries a stated reason', Boolean(classifySession({ turns: 3 }).reason));

  const cls = await execFileAsync(
    'node',
    [join(ROOT, 'bin', 'nightowl.mjs'), 'status', '--json', '--no-git', '--no-repo'],
    { env: { ...process.env, NIGHTOWL_CONFIG: configPath, NO_COLOR: '1' } },
  );
  const parsed = JSON.parse(cls.stdout);
  const names = parsed.candidates.map((c) => c.cwd.split('/').pop());
  const excludedFor = Object.fromEntries(parsed.excluded.map((e) => [e.cwd.split('/').pop(), e.reason]));

  assert('the chat fixture never reaches the candidate list', !names.includes('questions'), names.join(','));
  assert('and is reported as excluded, not silently dropped', excludedFor.questions === 'chat');
  assert('the research fixture is excluded by default', excludedFor.audit === 'research', JSON.stringify(excludedFor));

  const withResearch = await execFileAsync(
    'node',
    [join(ROOT, 'bin', 'nightowl.mjs'), 'status', '--json', '--no-git', '--no-repo', '--include-research'],
    { env: { ...process.env, NIGHTOWL_CONFIG: configPath, NO_COLOR: '1' } },
  );
  const rNames = JSON.parse(withResearch.stdout).candidates.map((c) => c.cwd.split('/').pop());
  assert('--include-research brings it back', rNames.includes('audit'), rNames.join(','));
  assert('but never brings back a chat', !rNames.includes('questions'));

  console.log('\n  scale and resilience\n');

  const { mapLimit } = await import(join(ROOT, 'lib', 'pool.mjs'));
  let inFlight = 0, peak = 0;
  await mapLimit(Array.from({ length: 200 }, (_, i) => i), 8, async (x) => {
    inFlight++; peak = Math.max(peak, inFlight);
    await new Promise((r) => setTimeout(r, 1));
    inFlight--;
    return x * 2;
  });
  assert('mapLimit never exceeds its ceiling', peak <= 8, `peak was ${peak}`);
  assert(
    'mapLimit preserves input order',
    (await mapLimit([1, 2, 3], 2, async (x) => x * 10)).join(',') === '10,20,30',
  );
  assert('mapLimit handles an empty list', (await mapLimit([], 4, async () => 1)).length === 0);

  console.log('\n  safety invariants\n');

  const dry = await execFileAsync(
    'node',
    [join(ROOT, 'bin', 'nightowl.mjs'), 'run'],
    { env: { ...process.env, NIGHTOWL_CONFIG: configPath, NO_COLOR: '1' } },
  );
  assert(
    'run without --go is a dry run',
    dry.stdout.includes('Nothing was spent'),
  );
  assert(
    'the dry run shows the exact prompt',
    dry.stdout.includes('REMAINING WORK'),
  );
  assert(
    'the prompt forbids git writes',
    dry.stdout.includes('Do not commit, push'),
  );

  await writeFile(
    '/tmp/nightowl-test-config-poor.json',
    JSON.stringify({ projectsDir: FIXTURES, quota: { blockLimit: 1000 } }),
  );
  const poor = await execFileAsync(
    'node',
    [join(ROOT, 'bin', 'nightowl.mjs'), 'run'],
    { env: { ...process.env, NIGHTOWL_CONFIG: '/tmp/nightowl-test-config-poor.json', NO_COLOR: '1' } },
  );
  assert(
    'an empty wallet is reported as such, not blamed on the candidate',
    poor.stdout.includes('No spendable budget'),
    poor.stdout.trim(),
  );
  assert(
    'and it still names what it would have picked',
    poor.stdout.includes('Best candidate when you have room'),
  );

  console.log(`\n  ${passed} passed, ${failed} failed\n`);
  if (failed) process.exitCode = 1;
}

run().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
