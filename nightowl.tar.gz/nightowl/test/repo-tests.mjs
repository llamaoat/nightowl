/**
 * Repo-evidence and verdict tests, against REAL git repositories.
 *
 * These build actual repos in /tmp rather than mocking git, because the whole
 * value of this layer is that it reports facts. A mock would only assert that
 * my assumptions are self-consistent.
 *
 * The invariant that matters most: the user is asked about almost nothing.
 * Every case git can settle on its own must NOT reach 'ambiguous'.
 */
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { mkdtemp, rm, mkdir, writeFile, appendFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';

const execFileAsync = promisify(execFile);
const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, '..');

let passed = 0, failed = 0;
function assert(name, cond, detail = '') {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else { failed++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
}

const work = await mkdtemp(join(tmpdir(), 'nightowl-repo-'));
const stateDir = join(work, 'state');
process.env.NIGHTOWL_STATE_DIR = stateDir;
await mkdir(stateDir, { recursive: true });

const { repoEvidence, evidenceVerdict, todoMatchesCommit } = await import(join(ROOT, 'lib', 'repo.mjs'));
const { setVerdict, loadVerdicts, applyVerdict } = await import(join(ROOT, 'lib', 'verdicts.mjs'));

async function repo(name, commits, { dirty = false, date = null } = {}) {
  const dir = join(work, name);
  await mkdir(dir, { recursive: true });
  await execFileAsync('git', ['init', '-q', '-b', 'main'], { cwd: dir });
  await execFileAsync('git', ['config', 'user.email', 't@t.t'], { cwd: dir });
  await execFileAsync('git', ['config', 'user.name', 'test'], { cwd: dir });
  for (const [i, subject] of commits.entries()) {
    await writeFile(join(dir, `f${i}.txt`), String(i));
    await execFileAsync('git', ['add', '-A'], { cwd: dir });
    const env = date ? { ...process.env, GIT_AUTHOR_DATE: date, GIT_COMMITTER_DATE: date } : process.env;
    await execFileAsync('git', ['commit', '-qm', subject], { cwd: dir, env });
  }
  if (dirty) await appendFile(join(dir, 'f0.txt'), 'wip');
  return dir;
}

const session = (cwd, todos, lastTimestamp, branch = 'main') => ({
  id: `sess-${Math.random().toString(36).slice(2, 8)}`,
  cwd, lastTimestamp, gitBranch: branch, filesTouched: [],
  todoRemaining: todos.map((t) => ({ content: t, status: 'pending' })),
  todoDone: 0, todoTotal: todos.length,
});

// `now` must be evaluated AFTER each repo is built, or the commits we just
// made look like they landed after the session ended and every case reads as
// 'live-repo'. Using a captured constant here silently broke three assertions.
const nowFn = () => Date.now();
const past = Date.now() - 10 * 86_400_000;

console.log('\n  todo/commit matching\n');
assert('matches a todo to its commit', todoMatchesCommit('Add unit tests for the parser', 'add unit tests for the parser') >= 0.6);
assert('matches despite rewording', todoMatchesCommit('Normalise currency codes', 'normalise the currency code handling') >= 0.6);
assert('does not match unrelated work', todoMatchesCommit('Add unit tests for the parser', 'bump dependencies') < 0.6);
assert('filler words alone never match', todoMatchesCommit('add the new thing', 'update the new stuff') < 0.6);

console.log('\n  evidence verdicts (against real repos)\n');

const superseded = await repo('superseded', ['parse pdf line items', 'add unit tests for the parser', 'update readme with usage examples']);
let r = evidenceVerdict(await repoEvidence(session(superseded, ['Add unit tests for the parser', 'Update README with usage examples'], past)), session(superseded, ['Add unit tests for the parser', 'Update README with usage examples'], past));
assert('detects work that landed without Claude', r.verdict === 'superseded', r.verdict);
assert('and effectively removes it from contention', r.multiplier <= 0.1);
assert('without needing to ask anyone', r.certainty === 'high');

const dead = await repo('dead', ['initial'], { date: '2024-01-01T00:00:00' });
r = evidenceVerdict(await repoEvidence(session(dead, ['Finish the thing'], past)), session(dead, ['Finish the thing'], past));
assert('detects a dormant repo', r.verdict === 'dead-repo', r.verdict);

const gone = await repo('gone', ['scaffold']);
const sGone = session(gone, ['Wire it up'], nowFn(), 'feature/deleted');
r = evidenceVerdict(await repoEvidence(sGone), sGone);
assert('detects a deleted branch', r.verdict === 'branch-gone', r.verdict);

const flight = await repo('flight', ['extract module'], { dirty: true });
const sFlight = session(flight, ['Migrate service 1'], nowFn());
r = evidenceVerdict(await repoEvidence(sFlight), sFlight);
assert('uncommitted work reads as in-flight', r.verdict === 'in-flight', r.verdict);
assert('and gets a modest boost', r.multiplier > 1);

const silent = await repo('silent', ['scaffold service']);
const sSilent = session(silent, ['Wire up the middleware'], nowFn());
const rSilent = evidenceVerdict(await repoEvidence(sSilent), sSilent);
assert('a live repo with no activity since is SILENT', rSilent.verdict === 'silent', rSilent.verdict);
assert('and is the only case marked ambiguous', rSilent.certainty === 'ambiguous');

console.log('\n  the ask gate (the user must almost never be bothered)\n');

const allCases = [
  ['superseded', evidenceVerdict(await repoEvidence(session(superseded, ['Add unit tests for the parser'], past)), session(superseded, ['Add unit tests for the parser'], past))],
  ['dead-repo', evidenceVerdict(await repoEvidence(session(dead, ['x'], past)), session(dead, ['x'], past))],
  ['branch-gone', evidenceVerdict(await repoEvidence(sGone), sGone)],
  ['in-flight', evidenceVerdict(await repoEvidence(sFlight), sFlight)],
  ['silent', rSilent],
];
const ambiguous = allCases.filter(([, v]) => v.certainty === 'ambiguous');
assert(
  `only 1 of ${allCases.length} evidence cases is worth asking about`,
  ambiguous.length === 1 && ambiguous[0][0] === 'silent',
  ambiguous.map(([n]) => n).join(','),
);

const nonGit = session(tmpdir(), ['x'], nowFn());
const rNon = evidenceVerdict(await repoEvidence(nonGit), nonGit);
assert('a non-git directory degrades to neutral, not to a question', rNon.verdict === 'no-repo' && rNon.multiplier === 1 && rNon.certainty !== 'ambiguous');

console.log('\n  stored verdicts\n');

await setVerdict('dead-one', 'dead');
await setVerdict('live-one', 'live');
await setVerdict('snoozed-one', 'snooze');
const all = await loadVerdicts();

assert('a dead verdict drops the candidate entirely', applyVerdict(all, 'dead-one') === null);
assert('an active snooze drops the candidate', applyVerdict(all, 'snoozed-one') === null);
assert('an expired snooze lets it back', applyVerdict(all, 'snoozed-one', Date.now() + 30 * 86_400_000) !== null);
assert('a live vouch boosts it', applyVerdict(all, 'live-one').multiplier > 1);
assert('a live vouch is marked so decay can be suspended', applyVerdict(all, 'live-one').vouched === true);
assert('a stale vouch stops boosting', applyVerdict(all, 'live-one', Date.now() + 40 * 86_400_000).multiplier === 1);
assert('an unknown session is unaffected', applyVerdict(all, 'never-seen').multiplier === 1);
assert('a bogus verdict is rejected', await setVerdict('x', 'maybe').then(() => false, () => true));

console.log('\n  verdict CLI (regression: prefix resolution)\n');

// The prefix must resolve against the CONFIGURED projects dir. Resolving
// against the default silently stored the prefix as the key, so the verdict
// was written, reported success, and then matched nothing.
const fixtures = join(work, 'projects');
await execFileAsync('node', [join(ROOT, 'test', 'make-fixtures.mjs'), fixtures]);
const cfg = join(work, 'cfg.json');
await writeFile(cfg, JSON.stringify({ projectsDir: fixtures, quota: { blockLimit: 200000 } }));
const env = { ...process.env, NIGHTOWL_CONFIG: cfg, NIGHTOWL_STATE_DIR: stateDir, NO_COLOR: '1' };

await execFileAsync('node', [join(ROOT, 'bin', 'nightowl.mjs'), 'verdict', 'aaaa1111', 'dead'], { env });
const after = await loadVerdicts();
const keys = Object.keys(after);
assert(
  'a prefix is expanded to the full session id',
  keys.some((k) => k.startsWith('aaaa1111-') && k.length > 20),
  keys.join(','),
);

const { stdout: js } = await execFileAsync(
  'node', [join(ROOT, 'bin', 'nightowl.mjs'), 'status', '--json', '--no-git', '--no-repo'], { env },
);
const listed = JSON.parse(js).candidates.map((c) => c.cwd.split('/').pop());
assert('a dead verdict actually removes the candidate', !listed.includes('invoice-parser'), listed.join(','));

const bad = await execFileAsync(
  'node', [join(ROOT, 'bin', 'nightowl.mjs'), 'verdict', 'zzzz9999', 'dead'], { env },
).then(() => null, (e) => e);
assert('an unmatched prefix is rejected rather than silently stored', bad !== null);

await rm(work, { recursive: true, force: true });
console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed) process.exitCode = 1;
