/**
 * Runner tests — the path that actually spends quota.
 *
 * Everything here runs against a FAKE `claude` binary that emits real
 * stream-json usage blocks, so the metering loop, the budget ceiling, the
 * tracker handshake and the cleanup are exercised for real rather than mocked.
 *
 * This path had no coverage until a manual run turned up two bugs: a missing
 * working directory reported as a missing binary, and a ceiling that overshoots
 * by one turn. Both are asserted below.
 */
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { mkdtemp, rm, mkdir, writeFile, chmod, readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, '..');

let passed = 0, failed = 0;
function assert(name, cond, detail = '') {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else { failed++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
}

const work = await mkdtemp(join(tmpdir(), 'nightowl-runner-'));
process.env.NIGHTOWL_STATE_DIR = join(work, 'state');
await mkdir(process.env.NIGHTOWL_STATE_DIR, { recursive: true });

// A fake agent CLI that emits metered turns forever until killed.
const binDir = join(work, 'bin');
await mkdir(binDir, { recursive: true });
const fake = join(binDir, 'fakeclaude.mjs');
await writeFile(fake, `#!/usr/bin/env node
const burn = Number(process.env.FAKE_BURN || 5000);
const turns = Number(process.env.FAKE_TURNS || 3);
let i = 0;
const t = setInterval(() => {
  if (i >= turns) { clearInterval(t); process.exit(0); }
  process.stdout.write(JSON.stringify({ type:'assistant', message:{ role:'assistant',
    content:[{type:'text',text:'turn '+i}],
    usage:{ input_tokens: burn, output_tokens: 0, cache_creation_input_tokens:0, cache_read_input_tokens:0 } } }) + '\\n');
  i++;
}, 20);
process.on('SIGTERM', () => { clearInterval(t); process.exit(143); });
`);
await chmod(fake, 0o755);

const { runCandidate, buildPrompt } = await import(join(ROOT, 'lib', 'runner.mjs'));
const { readState, ACTIVE_DIR } = await import(join(ROOT, 'lib', 'tracker.mjs'));
const { existsSync } = await import('node:fs');

const projectDir = join(work, 'project');
await mkdir(projectDir, { recursive: true });

const candidate = (cwd) => ({
  title: 'Add unit tests',
  session: { id: 'run-test-session', cwd,
    todoRemaining: [{ content: 'Add unit tests', status: 'pending' }], todoDone: 2, todoTotal: 3 },
});

// runCandidate(candidate, PROMPT, opts) — the fake binary goes in claudeBin,
// not in the prompt slot.
const opts = (extra = {}) => ({
  claudeBin: fake, cwd: projectDir, timeoutMs: 20_000, ...extra,
});
const PROMPT = 'do the work';

console.log('\n  the prompt\n');

const prompt = buildPrompt(candidate(projectDir), 30_000);
assert('states the budget', /30k tokens/.test(prompt));
assert('lists the remaining work', /Add unit tests/.test(prompt));
assert('forbids git writes', /Do not commit, push/.test(prompt));
assert('asks for a handoff note', /NIGHTOWL HANDOFF/.test(prompt));

console.log('\n  metering a real child process\n');

const withScript = (extra) => opts({ ...extra });
process.env.FAKE_TURNS = '3';
process.env.FAKE_BURN = '4000';

const done = await runCandidate(candidate(projectDir), PROMPT, withScript({ budgetTokens: 500_000, tracker: false }));
assert('a completing run exits zero', done.exitCode === 0, `exit ${done.exitCode}`);
assert('and reports a non-zero spend from the usage blocks', done.spent > 0, `spent ${done.spent}`);
assert('and is not marked as killed', done.killedForBudget === false);

console.log('\n  the budget ceiling\n');

process.env.FAKE_TURNS = '500';
const killed = await runCandidate(candidate(projectDir), PROMPT, withScript({ budgetTokens: 12_000, tracker: false }));
assert('an over-budget run is killed', killed.killedForBudget === true);
assert('and does not run to completion', killed.exitCode !== 0, `exit ${killed.exitCode}`);
assert('and stops near the ceiling rather than far past it',
  killed.spent < 12_000 * 2.5, `spent ${killed.spent} against a 12k ceiling`);
assert('the ceiling is exceeded, not respected exactly',
  killed.spent >= 12_000,
  'documented: enforced after each turn, so overshoot by up to one turn is expected');

console.log('\n  a working directory that no longer exists\n');

const deletedPath = join(work, 'deleted-project');
const gone = await runCandidate(candidate(deletedPath), PROMPT, withScript({ budgetTokens: 50_000, cwd: deletedPath }));
assert('is reported as a missing directory', gone.missingCwd === true, JSON.stringify(gone.error));
assert('and NOT blamed on the binary', !/PATH|ENOENT/.test(gone.error || ''), gone.error);
assert('and spends nothing', gone.spent === 0);

console.log('\n  tracker cleanup\n');

process.env.FAKE_TURNS = '3';
await runCandidate(candidate(projectDir), PROMPT, withScript({ budgetTokens: 500_000, tracker: true }));
assert('the active-run state is retired after a run',
  !existsSync(ACTIVE_DIR),
  'a stale state file makes the PostToolUse hook chatter in unrelated sessions');

await rm(work, { recursive: true, force: true });
console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed) process.exitCode = 1;
