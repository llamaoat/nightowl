/**
 * Generates a synthetic ~/.claude/projects tree so the pipeline can be tested
 * without touching (or needing) real transcripts.
 */
import { mkdir, writeFile, rm } from 'node:fs/promises';
import { join } from 'node:path';

const ROOT = process.argv[2] || '/tmp/nightowl-fixtures/projects';
const now = Date.now();
const H = 3_600_000;

function usage(i, o, cc = 0, cr = 0) {
  return { input_tokens: i, output_tokens: o, cache_creation_input_tokens: cc, cache_read_input_tokens: cr };
}

function user(text, t, sessionId, cwd) {
  return { type: 'user', sessionId, cwd, timestamp: new Date(t).toISOString(), message: { role: 'user', content: text } };
}

function assistant(content, t, sessionId, cwd, u) {
  return {
    type: 'assistant',
    sessionId,
    cwd,
    timestamp: new Date(t).toISOString(),
    message: { role: 'assistant', model: 'claude-opus-4', content, usage: u },
  };
}

function todoWrite(todos) {
  return [{ type: 'tool_use', id: 'tu_' + Math.random().toString(36).slice(2), name: 'TodoWrite', input: { todos } }];
}

const scenarios = [
  {
    // Near-done, killed by a rate limit, mechanical remaining work. Should win.
    slug: '-home-dev-invoice-parser',
    cwd: '/home/dev/invoice-parser',
    id: 'aaaa1111-1111-1111-1111-111111111111',
    startOffset: -3 * H,
    lines(id, cwd, t0) {
      const todos = [
        { content: 'Parse PDF line items', status: 'completed' },
        { content: 'Handle multi-page invoices', status: 'completed' },
        { content: 'Normalise currency codes', status: 'completed' },
        { content: 'Add unit tests for the parser', status: 'in_progress' },
        { content: 'Update README with usage examples', status: 'pending' },
      ];
      return [
        user('Finish the invoice parser', t0, id, cwd),
        assistant([{ type: 'text', text: 'Starting on the parser.' }], t0 + 60_000, id, cwd, usage(4000, 900, 12000, 30000)),
        assistant(todoWrite(todos), t0 + 120_000, id, cwd, usage(3000, 700, 0, 42000)),
        assistant([{ type: 'text', text: 'Currency normalisation is done and passing.' }], t0 + 900_000, id, cwd, usage(5000, 1400, 8000, 60000)),
        user('Claude usage limit reached. Resets at 4pm', t0 + 960_000, id, cwd),
      ];
    },
  },
  {
    // Parked on a question. High progress but terrible autonomy.
    slug: '-home-dev-auth-service',
    cwd: '/home/dev/auth-service',
    id: 'bbbb2222-2222-2222-2222-222222222222',
    startOffset: -20 * H,
    lines(id, cwd, t0) {
      const todos = [
        { content: 'Scaffold the service', status: 'completed' },
        { content: 'Choose a session store — Redis or Postgres?', status: 'in_progress' },
        { content: 'Wire up the middleware', status: 'pending' },
      ];
      return [
        user('Build the auth service', t0, id, cwd),
        assistant(todoWrite(todos), t0 + 60_000, id, cwd, usage(3000, 800, 9000, 20000)),
        assistant(
          [{ type: 'text', text: 'Before I continue — do you want sessions in Redis or Postgres?' }],
          t0 + 300_000,
          id,
          cwd,
          usage(2000, 600, 0, 25000),
        ),
      ];
    },
  },
  {
    // Genuinely finished. Should be filtered out or scored near zero.
    slug: '-home-dev-blog',
    cwd: '/home/dev/blog',
    id: 'cccc3333-3333-3333-3333-333333333333',
    startOffset: -30 * H,
    lines(id, cwd, t0) {
      const todos = [
        { content: 'Fix the RSS feed', status: 'completed' },
        { content: 'Add pagination', status: 'completed' },
      ];
      return [
        user('Fix the RSS feed and add pagination', t0, id, cwd),
        assistant(todoWrite(todos), t0 + 60_000, id, cwd, usage(2000, 500, 5000, 10000)),
        assistant([{ type: 'text', text: 'All tests pass. Done.' }], t0 + 200_000, id, cwd, usage(1500, 400, 0, 12000)),
      ];
    },
  },
  {
    // Huge remaining scope. Should be down-ranked on fit for a small budget.
    slug: '-home-dev-monolith',
    cwd: '/home/dev/monolith',
    id: 'dddd4444-4444-4444-4444-444444444444',
    startOffset: -6 * H,
    lines(id, cwd, t0) {
      const todos = [
        { content: 'Extract the billing module', status: 'completed' },
        ...Array.from({ length: 14 }, (_, i) => ({ content: `Migrate service ${i + 1} to the new interface`, status: 'pending' })),
      ];
      return [
        user('Break up the monolith', t0, id, cwd),
        assistant(todoWrite(todos), t0 + 60_000, id, cwd, usage(30000, 9000, 80000, 200000)),
        assistant([{ type: 'text', text: 'Billing is extracted. Long road ahead.' }], t0 + 600_000, id, cwd, usage(20000, 6000, 40000, 180000)),
      ];
    },
  },
  {
    // Stale but clean-scoped. Recency decay should push it down.
    slug: '-home-dev-cli-tool',
    cwd: '/home/dev/cli-tool',
    id: 'eeee5555-5555-5555-5555-555555555555',
    startOffset: -12 * 24 * H,
    lines(id, cwd, t0) {
      const todos = [
        { content: 'Add --json flag', status: 'completed' },
        { content: 'Write docs for the new flags', status: 'pending' },
      ];
      return [
        user('Polish the CLI', t0, id, cwd),
        assistant(todoWrite(todos), t0 + 60_000, id, cwd, usage(2500, 700, 6000, 15000)),
        assistant([{ type: 'text', text: 'Flag added.' }], t0 + 300_000, id, cwd, usage(1800, 500, 0, 18000)),
      ];
    },
  },
  {
    // A pure CHAT: questions and answers, nothing touched, no plan.
    slug: '-home-dev-questions',
    cwd: '/home/dev/questions',
    id: 'ffff6666-6666-6666-6666-666666666666',
    startOffset: -2 * H,
    lines(id, cwd, t0) {
      return [
        user('how does the event loop work?', t0, id, cwd),
        assistant([{ type: 'text', text: 'The event loop processes callbacks...' }], t0 + 30_000, id, cwd, usage(1200, 900, 0, 4000)),
        user('and microtasks?', t0 + 90_000, id, cwd),
        assistant([{ type: 'text', text: 'Microtasks drain before the next macrotask.' }], t0 + 120_000, id, cwd, usage(900, 700, 0, 5000)),
      ];
    },
  },
  {
    // RESEARCH: lots of reading, real duration, nothing written, no plan.
    slug: '-home-dev-audit',
    cwd: '/home/dev/audit',
    id: 'aaaa7777-7777-7777-7777-777777777777',
    startOffset: -5 * H,
    lines(id, cwd, t0) {
      const read = (path) => ({ type: 'tool_use', id: 'r' + Math.random(), name: 'Read', input: { file_path: path } });
      const grep = (q) => ({ type: 'tool_use', id: 'g' + Math.random(), name: 'Grep', input: { pattern: q } });
      return [
        user('audit this codebase for auth issues, do not change anything', t0, id, cwd),
        assistant([grep('authenticate')], t0 + 30_000, id, cwd, usage(2000, 400, 5000, 9000)),
        assistant([read('/home/dev/audit/auth.py')], t0 + 60_000, id, cwd, usage(2200, 500, 0, 12000)),
        assistant([read('/home/dev/audit/session.py')], t0 + 90_000, id, cwd, usage(2100, 450, 0, 14000)),
        assistant([grep('token')], t0 + 120_000, id, cwd, usage(1900, 400, 0, 15000)),
        assistant([{ type: 'text', text: 'Findings so far: three places skip validation.' }], t0 + 200_000, id, cwd, usage(2400, 1100, 0, 18000)),
        user('Claude usage limit reached. Resets at 9pm', t0 + 240_000, id, cwd),
      ];
    },
  },
];

await rm(ROOT, { recursive: true, force: true });

for (const sc of scenarios) {
  const dir = join(ROOT, sc.slug);
  await mkdir(dir, { recursive: true });
  const t0 = now + sc.startOffset;
  const lines = sc.lines(sc.id, sc.cwd, t0);
  await writeFile(join(dir, `${sc.id}.jsonl`), lines.map((l) => JSON.stringify(l)).join('\n') + '\n');
}

console.log(`wrote ${scenarios.length} fixture sessions to ${ROOT}`);
