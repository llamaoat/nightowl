---
name: nightowl
description: Show the user's unused Claude quota alongside a ranked list of their stalled, unfinished sessions, and offer to spend surplus quota finishing one. Use when the user asks what to work on with remaining tokens, mentions leftover, unused or expiring quota, asks what they left unfinished, asks which project is closest to done, or invokes /nightowl. Do not use for general usage statistics or cost reporting — that is what ccusage is for.
---

# nightowl

Turn about-to-expire quota into finished work.

## What this does

`nightowl` reads local Claude Code transcripts, estimates remaining headroom in
the current 5-hour window, and ranks stalled sessions by how likely that
headroom is to actually *finish* one of them.

It is not a usage reporter. The ranking is the product.

## Running it

The CLI ships with this plugin at `${CLAUDE_PLUGIN_ROOT}/bin/nightowl.mjs`.

```bash
# Dashboard: headroom + ranked candidates
node "${CLAUDE_PLUGIN_ROOT}/bin/nightowl.mjs" status

# Machine-readable — prefer this when you need to reason about the results
node "${CLAUDE_PLUGIN_ROOT}/bin/nightowl.mjs" status --json

# Why is this session ranked where it is?
node "${CLAUDE_PLUGIN_ROOT}/bin/nightowl.mjs" explain <session-id-prefix>
```

## How to present the results

Run `status --json`, then summarise conversationally. Lead with the number that
creates the decision:

> You've got about 90k of your 5-hour window left and it resets in 40 minutes.
> The best use of it is **invoice-parser** — 3 of 5 todos done, and it stopped
> at a usage limit rather than at completion. The two remaining items are tests
> and a README, both mechanical. Estimated cost to finish: ~30k.

Then name the runner-up in one line, and stop. Do not dump the whole JSON.

If `budget.blocked` is set, say so plainly and do not suggest running anything —
the reserves exist to protect the user's own next session.

If `urgency` is below 0.3, there is no time pressure. Mention the candidates
only if the user asked; otherwise say there's plenty of window left.

## Spending the budget

**Never run with `--go` unless the user has explicitly approved this specific
candidate in this conversation.** The dry run is the default for a reason.

Once they approve:

```bash
node "${CLAUDE_PLUGIN_ROOT}/bin/nightowl.mjs" run <session-id> --go
```

Add `--terse` if the user wants concise output, and `--allow-edits` only if the user asks for file changes. That flag forces
work into an isolated git worktree; if the worktree cannot be created, the run
aborts rather than touching their branch.

## The budget tracker

Runs ship with a budget tracker on by default. It re-injects remaining budget
into the model's context at the 50%, 75%, and 90% marks, each time with a
decision rule (explore / consolidate / wrap-up / land) rather than just a
number. Overhead is ~163 tokens per run. `--no-tracker` disables it.

If a run reports `killedForBudget`, the ceiling worked as designed — say so
plainly rather than treating it as a failure.

## Repo evidence

Before scoring, `nightowl` asks git what happened *after* each session ended:
remaining todos appearing in later commits (`superseded`), a dormant repo
(`dead-repo`), a deleted branch (`branch-gone`), uncommitted work still sitting
there (`in-flight`), or nothing at all (`silent`).

Each candidate in `--json` carries `evidenceVerdict` and `certainty`. When
summarising, lead with the evidence, not the score — "the last two todos show
up in commits from Tuesday, so that one's already done" is far more useful than
"score 4".

## Recording the user's answer

Only the `silent` verdict is ambiguous, and a `Stop` hook occasionally asks the
user to settle one. **If a `[nightowl]` housekeeping reminder appears asking
you to put a question to the user, ask it once, briefly, and only if they are
not mid-task.** Then record the answer:

```bash
nightowl verdict <session-id> live      # still working on it
nightowl verdict <session-id> dead      # never suggest it again
nightowl verdict <session-id> snooze     # hide it for a week
nightowl verdicts                        # list what they've ruled on
```

Run exactly one, using the full session id from the reminder. If the user
ignores the question or changes the subject, drop it silently and never raise
it again — the cooldown assumes a single ask.

The user can also volunteer these unprompted ("stop suggesting the auth thing").
Treat that as a `dead` verdict and record it.

## Interpreting the score

`score = finishability × autonomy × fit × 100`

- **finishability** — how close to done, weighted up if it stopped at a limit
  and down if the last message reads like a sign-off. Decays with staleness.
- **autonomy** — whether it can proceed without a human decision. A session
  parked on "Redis or Postgres?" scores near zero here no matter how close to
  done it is. This is the axis people forget.
- **fit** — whether the estimated remaining cost fits the spendable budget.

A zero on any axis zeroes the total. That is intentional. If the top score is
under 25, say there is nothing worth auto-resuming rather than picking the
least-bad option.

## Caveats to be honest about

The quota figures are **estimated locally** from transcript token counts,
calibrated against the user's own history. There is no public API that returns
a subscription's remaining tokens. If the user asks how accurate it is, say
this plainly — do not present the numbers as authoritative.
